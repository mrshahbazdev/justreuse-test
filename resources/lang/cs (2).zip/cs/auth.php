<?php
return array (
  'failed' => 'Tyto údaje neodpovídají našim záznamům.',
  'password' => 'Poskytnuté heslo je nesprávné.',
  'throttle' => 'Příliš mnoho pokusů o přihlášení. Zkuste to prosím znovu za :seconds sekund.',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat', 
);