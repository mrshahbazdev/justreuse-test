<?php
return array (
  'name' => 'Jméno',
  'email' => 'E-mail',
  'ad link' => 'Odkaz na inzerát',
  'phone' => 'Telefon',
  'description' => 'Popis',
  'attachment' => 'Příloha',
  'contact us' => 'Kontaktujte nás',
  'submit' => 'Odeslat',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat',  
);
