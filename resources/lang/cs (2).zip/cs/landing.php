<?php
return array (
  'sell and buy near you' => 'Prodej a koupě poblíž vás',
  'simple fast and efficient' => 'Jednoduché, rychlé a efektivní',
  'top ads' => 'Top inzeráty',
  'view more' => 'ZOBRAZIT VÍCE',
  'feature ads' => 'Vybrané inzeráty',
  'latest ads' => 'Nejnovější inzeráty',
  'browsecategory' => 'Procházet podle kategorie',
  'categories' => 'Kategorie',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat',  
);