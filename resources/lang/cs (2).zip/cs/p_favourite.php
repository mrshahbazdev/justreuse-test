<?php
return array (
  'favourite ads' => 'Oblíbené inzeráty',
  'select all' => 'Vybrat vše',
  'delete' => 'Smazat',
  'search here' => 'Hledat zde',
  'photo' => 'Fotografie',
  'ads details' => 'Detaily inzerátů',
  'price' => 'Cena',
  'action' => 'Akce',
  'posted on' => 'Zveřejněno dne',
  'no data found' => 'Nebyly nalezeny žádné údaje!',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat',  
);