<?php
return array (
  'packages' => 'Balíčky',
'package quotes' => 'Prémiový balíček pomáhá prodejcům propagovat své produkty nebo služby tím, že poskytuje větší viditelnost jejich inzerátů, aby přilákal více kupujících a prodával rychleji',
'ad' => 'Inzerát',
'availability' => 'Dostupnost',
'days' => 'Dny',
'promo duration' => 'Doba propagace',
'ad limit' => 'Limit inzerátů',
'ad type' => 'Typ inzerátu',
'business package' => 'Firemní balíček',
'coupons' => 'Slevové kupony',
'coupon code' => 'Kód kupónu',
'offer' => 'Nabídka',
'validity' => 'Platnost',
'choose' => 'Vyberte své kategorie',
'done' => 'Hotovo',
'sell' => 'Prodat',
);