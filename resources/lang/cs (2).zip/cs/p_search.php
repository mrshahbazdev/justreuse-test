<?php
return array (
  'all categories' => 'Všechny kategorie',
  'location' => 'Lokalita',
  'sort_by_colon' => 'Seřadit podle: ',
  'recently_posted' => 'Nedávno zveřejněno',
  'price_low_to_high' => 'Cena: Od nejnižší k nejvyšší',
  'price_high_to_low' => 'Cena: Od nejvyšší k nejnižší',
  'popular' => 'Populární',
  'Brands' => 'Značky',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat',  
);