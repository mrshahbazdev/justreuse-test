<?php
return array (
  'previous' => '&laquo; Předchozí',
'next' => 'Další &raquo;',
'choose' => 'Vyberte své kategorie',
'done' => 'Hotovo',
'sell' => 'Prodat',
);