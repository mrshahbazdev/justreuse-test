<?php
return array (
  'reset' => 'Vaše heslo bylo obnoveno!',
  'sent' => 'Poslali jsme vám e-mail s odkazem na obnovení hesla!',
  'throttled' => 'Před dalším pokusem vyčkejte.',
  'token' => 'Tento token pro obnovení hesla je neplatný.',
  'user' => 'Nemůžeme najít uživatele s touto e-mailovou adresou.',
  'choose' => 'Vyberte své kategorie',
  'done' => 'Hotovo',
  'sell' => 'Prodat',
);