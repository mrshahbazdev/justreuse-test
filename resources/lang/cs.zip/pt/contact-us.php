<?php
return array (
  'name' => 'Nome',
'email' => 'E-mail',
'ad link' => 'Link do Anúncio',
'phone' => 'Telefone',
'description' => 'Descrição',
'attachment' => 'Anexo',
'contact us' => 'Contate-nos',
'submit' => 'Enviar',
'choose' => 'Escolha suas categorias',
'done' => 'Concluído',
'sell' => 'Vender',

);