<?php
return array (
  'sell and buy near you' => 'Venda e Compra perto de você',
'simple fast and efficient' => 'Simples, rápido e eficiente',
'top ads' => 'Anúncios Principais',
'view more' => 'VER MAIS',
'feature ads' => 'Anúncios em Destaque',
'latest ads' => 'Últimos Anúncios',
'browsecategory' => 'Navegue por categoria',
'categories' => 'Categorias',
'choose' => 'Escolha suas categorias',
'done' => 'Concluído',
'sell' => 'Vender',

);