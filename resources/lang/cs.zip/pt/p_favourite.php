<?php
return array (
  'favourite ads' => 'Anúncios Favoritos',
'select all' => 'Selecionar Tudo',
'delete' => 'Apagar',
'search here' => 'Buscar Aqui',
'photo' => 'Foto',
'ads details' => 'Detalhes do Anúncio',
'price' => 'Preço',
'action' => 'Ação',
'posted on' => 'Publicado Em',
'no data found' => 'Nenhum dado encontrado!',
'choose' => 'Escolha suas categorias',
'done' => 'Concluído',
'sell' => 'Vender',

);