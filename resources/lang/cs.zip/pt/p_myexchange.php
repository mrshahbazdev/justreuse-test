<?php
return array (
  'my exchange' => 'Minha Troca',
'incoming requests' => 'Pedidos Recebidos',
'outgoing requests' => 'Pedidos Enviados',
'successful exchanges' => 'Trocas Bem-sucedidas',
'failed exchanges' => 'Trocas Mal-sucedidas',
'current status' => 'Status Atual',
'exchange initiated on' => 'Troca Iniciada em',
'accept' => 'ACEITAR',
'decline' => 'RECUSAR',
'success' => 'SUCESSO',
'failed' => 'FALHA',
'no data found' => 'Nenhum dado encontrado',
'cancel' => 'CANCELAR',
'block exchange' => 'BLOQUEAR TROCA',
'unblock exchange' => 'DESBLOQUEAR TROCA',
'owner' => 'Proprietário',
'choose' => 'Escolha suas categorias',
'done' => 'Concluído',
'sell' => 'Vender',

);