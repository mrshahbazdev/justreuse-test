<?php
return array (
  'packages' => 'Pacotes',
  'package quotes' => 'O pacote premium ajuda os vendedores a promover seus produtos ou serviços, dando mais visibilidade aos seus anúncios para atrair mais compradores e vender mais rapidamente.',
  'ad' => 'Anúncio',
  'availability' => 'Disponibilidade',
  'days' => 'Dias',
  'promo duration' => 'Duração da Promoção',
  'ad limit' => 'Limite do Anúncio',
  'ad type' => 'Tipo de Anúncio',
  'business package' => 'Pacote Empresarial',
  'coupons' => 'Cupons',
  'coupon code' => 'Código do Cupom',
  'offer' => 'Oferta',
  'validity' => 'Validade',
  'choose' => 'Escolha suas categorias',
  'done' => 'Concluído',
  'sell' => 'Vender',
  
);