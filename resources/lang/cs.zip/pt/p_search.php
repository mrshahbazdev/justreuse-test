<?php
return array (
  'all categories' => 'Todas as Categorias',
  'location' => 'Localização',
  'sort_by_colon' => 'Ordenar Por: ',
  'recently_posted' => 'Postado Recentemente',
  'price_low_to_high' => 'Preço: Baixo para Alto',
  'price_high_to_low' => 'Preço: Alto para Baixo',
  'popular' => 'Popular',
  'Brands' => 'Marcas',
  'choose' => 'Escolha suas categorias',
  'done' => 'Concluído',
  'sell' => 'Vender',  
);