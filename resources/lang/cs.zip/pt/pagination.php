<?php
return array (
  'previous' => '&laquo; Anterior',
'next' => 'Próximo &raquo;',
'choose' => 'Escolha suas categorias',
'done' => 'Concluído',
'sell' => 'Vender',

);