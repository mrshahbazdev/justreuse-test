<?php
return array (
  'reset' => 'Sua senha foi redefinida!',
  'sent' => 'Enviamos o link de redefinição de senha para o seu email!',
  'throttled' => 'Aguarde antes de tentar novamente.',
  'token' => 'Este token de redefinição de senha é inválido.',
  'user' => 'Não conseguimos encontrar um usuário com esse endereço de email.',
  'choose' => 'Escolha suas categorias',
  'done' => 'Concluído',
  'sell' => 'Vender',
  
);