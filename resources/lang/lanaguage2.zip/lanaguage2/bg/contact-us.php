<?php
return array (
  'name' => 'Име',
  'email' => 'Имейл',
  'ad link' => 'Връзка към обявата',
  'phone' => 'Телефон',
  'description' => 'Описание',
  'attachment' => 'Прикачен файл',
  'contact us' => 'Свържете се с нас',
  'submit' => 'Изпрати',
  'choose' => 'Изберете вашите категории',
  'done' => 'Готово',
  'sell' => 'Продавам',  
);