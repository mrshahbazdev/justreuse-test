<?php
return array (
  'sell and buy near you' => 'Продавайте и купувайте близо до вас',
  'simple fast and efficient' => 'Просто, бързо и ефективно',
  'top ads' => 'Най-добри обяви',
  'view more' => 'ВИЖ ОЩЕ',
  'feature ads' => 'Представени обяви',
  'latest ads' => 'Последни обяви',
  'browsecategory' => 'Прегледайте по категория',
  'categories' => 'Категории',
  'choose' => 'Изберете вашите категории',
  'done' => 'Готово',
  'sell' => 'Продавам',  
);