<?php
return array (
  'favourite ads' => 'Любими Обяви',
'select all' => 'Избери всичко',
'delete' => 'Изтрий',
'search here' => 'Търси тук',
'photo' => 'Снимка',
'ads details' => 'Детайли за Обявите',
'price' => 'Цена',
'action' => 'Действие',
'posted on' => 'Публикувана на',
'no data found' => 'Няма намерени данни!',
'choose' => 'Изберете вашите категории',
'done' => 'Готово',
'sell' => 'Продавам',
);