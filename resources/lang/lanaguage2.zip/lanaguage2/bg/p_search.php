<?php
return array (
  'all categories' => 'Всички категории',
  'location' => 'Местоположение',
  'sort_by_colon' => 'Подреди по: ',
  'recently_posted' => 'Скоро публикувани',
  'price_low_to_high' => 'Цена: Ниска към висока',
  'price_high_to_low' => 'Цена: Висока към ниска',
  'popular' => 'Популярни',
  'Brands' => 'Марки',
  'choose' => 'Изберете вашите категории',
  'done' => 'Готово',
  'sell' => 'Продавам',  
);