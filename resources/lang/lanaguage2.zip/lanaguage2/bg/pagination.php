<?php
return array (
  'previous' => '&laquo; Предишен',
  'next' => 'Следващ &raquo;',
  'choose' => 'Изберете вашите категории',
  'done' => 'Готово',
  'sell' => 'Продавам',  
);