<?php
return array (
  'failed' => 'Ove vjerodajnice ne odgovaraju našoj evidenciji.',
  'password' => 'Navedena lozinka je netočna.',
  'throttle' => 'Previše pokušaja prijave. Pokušajte ponovno za :seconds sekundi.',
  'choose' => 'Odaberite svoje kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja'
);