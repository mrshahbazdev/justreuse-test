<?php
return array (
  'name' => 'Ime',
  'email' => 'E-pošta',
  'ad link' => 'Poveznica oglasa',
  'phone' => 'Telefon',
  'description' => 'Opis',
  'attachment' => 'Privitak',
  'contact us' => 'Kontaktirajte nas',
  'submit' => 'Pošalji',
  'choose' => 'Odaberite kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja',
  
);