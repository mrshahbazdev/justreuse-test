<?php
return array (
  'sell and buy near you' => 'Prodajte i kupujte u blizini vas',
  'simple fast and efficient' => 'Jednostavno, brzo i učinkovito',
  'top ads' => 'Najbolji oglasi',
  'view more' => 'PRIKAŽI VIŠE',
  'feature ads' => 'Istaknuti oglasi',
  'latest ads' => 'Najnoviji oglasi',
  'browsecategory' => 'Pregledajte po kategoriji',
  'categories' => 'Kategorije',
  'choose' => 'Odaberite svoje kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja',  
);