<?php
return array (
  'favourite ads' => 'Omiljeni oglasi',
'select all' => 'Odaberi sve',
'delete' => 'Izbriši',
'search here' => 'Pretraži ovdje',
'photo' => 'Fotografija',
'ads details' => 'Detalji oglasa',
'price' => 'Cijena',
'action' => 'Radnja',
'posted on' => 'Objavljeno',
'no data found' => 'Nema pronađenih podataka!',
'choose' => 'Odaberite svoje kategorije',
'done' => 'Gotovo',
'sell' => 'Prodaja',
);