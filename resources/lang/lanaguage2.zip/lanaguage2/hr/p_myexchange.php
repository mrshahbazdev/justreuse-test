<?php
return array (
  'my exchange' => 'Moja razmjena',
  'incoming requests' => 'Dolazni zahtjevi',
  'outgoing requests' => 'Odlazni zahtjevi',
  'successful exchanges' => 'Uspješne razmjene',
  'failed exchanges' => 'Neuspjele razmjene',
  'current status' => 'Trenutni status',
  'exchange initiated on' => 'Razmjena započeta na',
  'accept' => 'PRIHVATI',
  'decline' => 'ODBACI',
  'success' => 'USPJEŠNO',
  'failed' => 'NEUSPJEŠNO',
  'no data found' => 'Nema pronađenih podataka',
  'cancel' => 'ODUSTANI',
  'block exchange' => 'BLOKIRAJ RAZMJENU',
  'unblock exchange' => 'ODBLOKIRAJ RAZMJENU',
  'owner' => 'Vlasnik',
  'choose' => 'Odaberite svoje kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja',
  
);