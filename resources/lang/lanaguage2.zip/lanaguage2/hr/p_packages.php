<?php
return array (
  'packages' => 'Paketi',
  'package quotes' => 'Premium paket pomaže prodavačima da promoviraju svoje proizvode ili usluge pružajući veću vidljivost njihovim oglasima kako bi privukli više kupaca i brže prodali.',
  'ad' => 'Oglas',
  'availability' => 'Dostupnost',
  'days' => 'Dana',
  'promo duration' => 'Trajanje promocije',
  'ad limit' => 'Limit oglasa',
  'ad type' => 'Vrsta oglasa',
  'business package' => 'Poslovni paket',
  'coupons' => 'Kuponi',
  'coupon code' => 'Kod kupona',
  'offer' => 'Ponuda',
  'validity' => 'Valjanost',
  'choose' => 'Odaberite svoje kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja',
  
);