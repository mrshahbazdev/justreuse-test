<?php
return array (
  'all categories' => 'Sve kategorije',
'location' => 'Lokacija',
'sort_by_colon' => 'Sortiraj po: ',
'recently_posted' => 'Nedavno objavljeno',
'price_low_to_high' => 'Cijena: Od najniže do najviše',
'price_high_to_low' => 'Cijena: Od najviše do najniže',
'popular' => 'Popularno',
'Brands' => 'Brendovi',
'choose' => 'Odaberite svoje kategorije',
'done' => 'Gotovo',
'sell' => 'Prodaja',

);