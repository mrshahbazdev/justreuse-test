<?php
return array (
  'previous' => '&laquo; Prethodno',
  'next' => 'Sljedeće &raquo;',
  'choose' => 'Odaberite svoje kategorije',
  'done' => 'Gotovo',
  'sell' => 'Prodaja',
  
);