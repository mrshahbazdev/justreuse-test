<?php
return array (
  'reset' => 'Vaša lozinka je resetirana!',
'sent' => 'Poslali smo vam e-poštom poveznicu za resetiranje lozinke!',
'throttled' => 'Pričekajte prije ponovnog pokušaja.',
'token' => 'Ovaj token za resetiranje lozinke nije valjan.',
'user' => 'Ne možemo pronaći korisnika s tom e-adresom.',
'choose' => 'Odaberite svoje kategorije',
'done' => 'Gotovo',
'sell' => 'Prodaja',

);