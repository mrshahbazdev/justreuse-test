<?php
return array (
  'accepted' => 'Polje :attribute mora biti prihvaćeno.',
'active_url' => 'Polje :attribute nije valjani URL.',
'after' => 'Polje :attribute mora biti datum nakon :date.',
'after_or_equal' => 'Polje :attribute mora biti datum nakon ili jednak :date.',
'alpha' => 'Polje :attribute može sadržavati samo slova.',
'alpha_dash' => 'Polje :attribute može sadržavati samo slova, brojeve, crtice i donje crte.',
'alpha_num' => 'Polje :attribute može sadržavati samo slova i brojeve.',
'array' => 'Polje :attribute mora biti niz.',
'before' => 'Polje :attribute mora biti datum prije :date.',
'before_or_equal' => 'Polje :attribute mora biti datum prije ili jednak :date.',
'between' => 
  array (
    'numeric' => 'Polje :attribute mora biti između :min i :max.',
    'file' => 'Polje :attribute mora biti između :min i :max kilobajta.',
    'string' => 'Polje :attribute mora biti između :min i :max znakova.',
    'array' => 'Polje :attribute mora imati između :min i :max stavki.',
  ),
'boolean' => 'Polje :attribute mora biti istinito ili lažno.',
'confirmed' => 'Potvrda polja :attribute se ne podudara.',
'date' => 'Polje :attribute nije valjani datum.',
'date_equals' => 'Polje :attribute mora biti datum jednak :date.',
'date_format' => 'Polje :attribute se ne podudara s formatom :format.',
'different' => 'Polje :attribute i :other moraju biti različiti.',
'digits' => 'Polje :attribute mora biti :digits znamenki.',
'digits_between' => 'Polje :attribute mora biti između :min i :max znamenki.',
'dimensions' => 'Polje :attribute ima nevaljane dimenzije slike.',
'distinct' => 'Polje :attribute ima duplu vrijednost.',
'email' => 'Polje :attribute mora biti valjana email adresa.',
'ends_with' => 'Polje :attribute mora završavati jednim od sljedećeg: :values.',
'exists' => 'Odabrano polje :attribute nije valjano.',
'file' => 'Polje :attribute mora biti datoteka.',
'filled' => 'Polje :attribute mora imati vrijednost.',
'gt' => 
  array (
    'numeric' => 'Polje :attribute mora biti veće od :value.',
    'file' => 'Polje :attribute mora biti veće od :value kilobajta.',
    'string' => 'Polje :attribute mora imati više od :value znakova.',
    'array' => 'Polje :attribute mora imati više od :value stavki.',
  ),
'gte' => 
  array (
    'numeric' => 'Polje :attribute mora biti veće ili jednako :value.',
    'file' => 'Polje :attribute mora biti veće ili jednako :value kilobajta.',
    'string' => 'Polje :attribute mora biti veće ili jednako :value znakova.',
    'array' => 'Polje :attribute mora imati :value stavki ili više.',
  ),
'image' => 'Polje :attribute mora biti slika.',
'in' => 'Odabrano polje :attribute nije valjano.',
'in_array' => 'Polje :attribute ne postoji u :other.',
'integer' => 'Polje :attribute mora biti cijeli broj.',
'ip' => 'Polje :attribute mora biti valjana IP adresa.',
'ipv4' => 'Polje :attribute mora biti valjana IPv4 adresa.',
'ipv6' => 'Polje :attribute mora biti valjana IPv6 adresa.',
'json' => 'Polje :attribute mora biti valjan JSON.',
'lt' => 
  array (
    'numeric' => 'Polje :attribute mora biti manje od :value.',
    'file' => 'Polje :attribute mora biti manje od :value kilobajta.',
    'string' => 'Polje :attribute mora biti manje od :value znakova.',
    'array' => 'Polje :attribute mora imati manje od :value stavki.',
  ),
'lte' => 
  array (
    'numeric' => 'Polje :attribute mora biti manje ili jednako :value.',
    'file' => 'Polje :attribute mora biti manje ili jednako :value kilobajta.',
    'string' => 'Polje :attribute mora biti manje ili jednako :value znakova.',
    'array' => 'Polje :attribute ne smije imati više od :value stavki.',
  ),
'max' => 
  array (
    'numeric' => 'Polje :attribute ne smije biti veće od :max.',
    'file' => 'Polje :attribute ne smije biti veće od :max kilobajta.',
    'string' => 'Polje :attribute ne smije biti veće od :max znakova.',
    'array' => 'Polje :attribute ne smije imati više od :max stavki.',
  ),
'mimes' => 'Polje :attribute mora biti datoteka tipa: :values.',
'mimetypes' => 'Polje :attribute mora biti datoteka tipa: :values.',
'min' => 
  array (
    'numeric' => 'Polje :attribute mora biti najmanje :min.',
    'file' => 'Polje :attribute mora biti najmanje :min kilobajta.',
    'string' => 'Polje :attribute mora biti najmanje :min znakova.',
    'array' => 'Polje :attribute mora imati najmanje :min stavki.',
  ),
'multiple_of' => 'Polje :attribute mora biti višekratnik od :value',
'not_in' => 'Odabrano polje :attribute nije valjano.',
'not_regex' => 'Format polja :attribute nije valjan.',
'numeric' => 'Polje :attribute mora biti broj.',
'password' => 'Lozinka je neispravna.',
'present' => 'Polje :attribute mora biti prisutno.',
'regex' => 'Format polja :attribute nije valjan.',
'required' => 'Polje :attribute je obavezno.',
'required_if' => 'Polje :attribute je obavezno kada je :other :value.',
'required_unless' => 'Polje :attribute je obavezno osim ako je :other u :values.',
'required_with' => 'Polje :attribute je obavezno kada je :values prisutno.',
'required_with_all' => 'Polje :attribute je obavezno kada su prisutni :values.',
'required_without' => 'Polje :attribute je obavezno kada :values nije prisutno.',
'required_without_all' => 'Polje :attribute je obavezno kada nijedan od :values nije prisutan.',
'same' => 'Polje :attribute i :other moraju se podudarati.',
'size' => 
  array (
    'numeric' => 'Polje :attribute mora biti :size.',
    'file' => 'Polje :attribute mora biti :size kilobajta.',
    'string' => 'Polje :attribute mora biti :size znakova.',
    'array' => 'Polje :attribute mora sadržavati :size stavki.',
  ),
'starts_with' => 'Polje :attribute mora počinjati s jednim od sljedećeg: :values.',
'string' => 'Polje :attribute mora biti niz znakova.',
'timezone' => 'Polje :attribute mora biti valjana vremenska zona.',
'unique' => 'Polje :attribute već postoji.',
'uploaded' => 'Polje :attribute nije uspjelo učitavanje.',
'url' => 'Format polja :attribute nije valjan.',
'uuid' => 'Polje :attribute mora biti valjani UUID.',
'custom' => 
  array (
    'attribute-name' => 
    array (
      'rule-name' => 'prilagođena-poruka',
    ),
  ),
'attributes' => 
  array (
  ),
'choose' => 'Odaberite svoje kategorije',
'done' => 'Gotovo',
'sell' => 'Prodaja',

);