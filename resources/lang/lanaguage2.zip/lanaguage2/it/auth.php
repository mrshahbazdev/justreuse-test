<?php
return array (
  'failed' => 'Queste credenziali non corrispondono ai nostri record.',
  'password' => 'La password fornita non è corretta.',
  'throttle' => 'Troppi tentativi di accesso. Si prega di riprovare tra :seconds secondi.',
  'choose' => 'Scegli le tue categorie',
  'done' => 'Fatto',
  'sell' => 'Vendere',
  
);