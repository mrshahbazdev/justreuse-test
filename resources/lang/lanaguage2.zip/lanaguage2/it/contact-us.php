<?php
return array (
  'name' => 'Nome',
  'email' => 'Email',
  'ad link' => 'Link dell\'annuncio',
  'phone' => 'Telefono',
  'description' => 'Descrizione',
  'attachment' => 'Allegato',
  'contact us' => 'Contattaci',
  'submit' => 'Invia',
  'choose' => 'Scegli le tue categorie',
  'done' => 'Fatto',
  'sell' => 'Vendere',
  
);