<?php
return array (
  'favourite ads' => 'Annunci Preferiti',
  'select all' => 'Seleziona: Tutti',
  'delete' => 'Elimina',
  'search here' => 'Cerca qui',
  'photo' => 'Foto',
  'ads details' => 'Dettagli Annunci',
  'price' => 'Prezzo',
  'action' => 'Azione',
  'posted on' => 'Pubblicato il',
  'no data found' => 'Nessun dato trovato!',
  'choose' => 'Scegli le tue categorie',
  'done' => 'Fatto',
  'sell' => 'Vendere',  
);