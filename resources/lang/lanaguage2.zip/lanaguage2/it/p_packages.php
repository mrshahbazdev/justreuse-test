<?php
return array (
  'packages' => 'Pacchetti',
'package quotes' => 'Il pacchetto premium aiuta i venditori a promuovere i loro prodotti o servizi dando maggiore visibilità ai loro annunci per attirare più acquirenti e vendere più velocemente.',
'ad' => 'Annuncio',
'availability' => 'Disponibilità',
'days' => 'Giorni',
'promo duration' => 'Durata promozionale',
'ad limit' => 'Limite annuncio',
'ad type' => 'Tipo di annuncio',
'business package' => 'Pacchetto Business',
'coupons' => 'Buoni',
'coupon code' => 'Codice coupon',
'offer' => 'Offerta',
'validity' => 'Validità',
'choose' => 'Scegli le tue categorie',
'done' => 'Fatto',
'sell' => 'Vendere',

);