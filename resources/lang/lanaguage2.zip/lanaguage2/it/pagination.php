<?php
return array (
  'previous' => '&laquo; Precedente',
  'next' => 'Successivo &raquo;',
  'choose' => 'Scegli le tue categorie',
  'done' => 'Fatto',
  'sell' => 'Vendere',  
);