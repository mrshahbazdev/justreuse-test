<?php
return array (
  'failed' => 'Aceste credențiale nu se potrivesc înregistrărilor noastre.',
'password' => 'Parola furnizată este incorectă.',
'throttle' => 'Prea multe încercări de conectare. Vă rugăm să încercați din nou în :seconds secunde.',
'choose' => 'Alegeți categoriile dvs.',
'done' => 'Gata',
'sell' => 'Vinde',

);