<?php
return array (
  'name' => 'Nume',
  'email' => 'Email',
  'ad link' => 'Link Anunț',
  'phone' => 'Telefon',
  'description' => 'Descriere',
  'attachment' => 'Atașament',
  'contact us' => 'Contactează-ne',
  'submit' => 'Trimite',
  'choose' => 'Alegeți categoriile dvs.',
  'done' => 'Gata',
  'sell' => 'Vinde',
  
);