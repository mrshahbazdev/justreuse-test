<?php
return array (
  'sell and buy near you' => 'Vând și cumperi în apropiere de tine',
  'simple fast and efficient' => 'Simplu, rapid și eficient',
  'top ads' => 'Anunțuri top',
  'view more' => 'VEZI MAI MULT',
  'feature ads' => 'Anunțuri de featură',
  'latest ads' => 'Anunțuri cele mai recente',
  'browsecategory' => 'Parcurge categoriele',
  'categories' => 'Categorii',
  'choose' => 'Alege categoriile tale',
  'done' => 'Încheiat',
  'sell' => 'Vând',
);