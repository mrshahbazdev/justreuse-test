<?php
return array (
  'favourite ads' => 'Anunțuri favorite',
    'select all' => 'Selectează toate',
    'delete' => 'Șterge',
    'search here' => 'Caută aici',
    'photo' => 'Foto',
    'ads details' => 'Detalii anunțuri',
    'price' => 'Preț',
    'action' => 'Acțiune',
    'posted on' => 'Publicat pe',
    'no data found' => 'Datele nu au fost găsite!',
    'choose' => 'Alege categoriile tale',
    'done' => 'Încheiat',
    'sell' => 'Vând',
);
