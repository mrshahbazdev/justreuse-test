<?php
return array (
  'packages' => 'Pachete',
    'package quotes' => 'Pachetul premium ajută vânzătorii să promoveze produsele sau serviciile lor prin oferirea unei vizibilități mai mari anunțurilor lor pentru a atrage mai mulți cumpărători și a vinde mai repede',
    'ad' => 'Anunț',
    'availability' => 'Disponibilitate',
    'days' => 'Zile',
    'promo duration' => 'Durata promoției',
    'ad limit' => 'Limită anunț',
    'ad type' => 'Tipul anunțului',
    'business package' => 'Pachet de afaceri',
    'coupons' => 'Cupone',
    'coupon code' => 'Cod cupon',
    'offer' => 'Ofertă',
    'validity' => 'Valabilitate',
    'choose' => 'Alege categoriile tale',
    'done' => 'Încheiat',
    'sell' => 'Vând',
);