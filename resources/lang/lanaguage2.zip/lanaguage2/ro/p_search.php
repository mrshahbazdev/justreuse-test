<?php
return array (
  'all categories' => 'Toate categoriile',
    'location' => 'Locație',
    'sort_by_colon' => 'Sortează după: ',
    'recently_posted' => 'Recent postat',
    'price_low_to_high' => 'Preț: Din scăzut la mare',
    'price_high_to_low' => 'Preț: Din mare la scăzut',
    'popular' => 'Popular',
    'Brands' => 'Mărci',
    'choose' => 'Alege categoriile tale',
    'done' => 'Încheiat',
    'sell' => 'Vând',
);