<?php
return array (
  'previous' => '&laquo; Anterior',
  'next' => 'Următorul &raquo;',
  'choose' => 'Alege categoriile tale',
  'done' => 'Încheiat',
  'sell' => 'Vând',
);