<?php
return array (
  'reset' => 'Parola ta a fost restabilită!',
    'sent' => 'Am trimis linkul de restabilire a parolei!',
    'throttled' => 'Te rog să aștepți înainte de a încerca din nou.',
    'token' => 'Acest token de restabilire a parolei este invalid.',
    'user' => 'Nu am putea găsi un utilizator cu această adresă de e-mail.',
    'choose' => 'Alege categoriile tale',
    'done' => 'Încheiat',
    'sell' => 'Vând',
);