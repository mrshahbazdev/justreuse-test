<?php
return array (
  'failed' => 'Ovi podaci se ne podudaraju sa našim zapisima.',
'password' => 'Uneta lozinka nije tačna.',
'throttle' => 'Previše pokušaja prijave. Molimo vas da pokušate ponovo za :seconds sekundi.',
'choose' => 'Izaberite svoje kategorije',
'done' => 'Završeno',
'sell' => 'Prodaja',

);