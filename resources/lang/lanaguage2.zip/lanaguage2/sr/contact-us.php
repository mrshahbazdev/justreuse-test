<?php
return array (
  'name' => 'Ime',
  'email' => 'Email',
  'ad link' => 'Veza oglasa',
  'phone' => 'Telefon',
  'description' => 'Opis',
  'attachment' => 'Prilog',
  'contact us' => 'Kontaktirajte nas',
  'submit' => 'Podnesi',
  'choose' => 'Izaberite svoje kategorije',
  'done' => 'Završeno',
  'sell' => 'Prodaja',  
);