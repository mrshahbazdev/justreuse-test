<?php
return array (
  'sell and buy near you' => 'Prodaja i kupovina u vašoj blizini',
  'simple fast and efficient' => 'Jednostavno, brzo i efikasno',
  'top ads' => 'Najbolji oglasi',
  'view more' => 'Pogledaj više',
  'feature ads' => 'Istaknuti oglasi',
  'latest ads' => 'Najnoviji oglasi',
  'browsecategory' => 'Pregledaj po kategoriji',
  'categories' => 'Kategorije',
  'choose' => 'Izaberite svoje kategorije',
  'done' => 'Završeno',
  'sell' => 'Prodaja',  
);