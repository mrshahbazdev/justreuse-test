<?php
return array (
  'favourite ads' => 'Omiljeni oglasi',
'select all' => 'Izaberite: Sve',
'delete' => 'Obriši',
'search here' => 'Pretraži ovde',
'photo' => 'Fotografija',
'ads details' => 'Detalji oglasa',
'price' => 'Cena',
'action' => 'Akcija',
'posted on' => 'Objavljeno',
'no data found' => 'Nema pronađenih podataka!',
'choose' => 'Izaberite svoje kategorije',
'done' => 'Gotovo',
'sell' => 'Prodaja',
);