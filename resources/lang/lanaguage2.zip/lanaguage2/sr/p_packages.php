<?php
return array (
  'packages' => 'Paketi',
  'package quotes' => 'Premium paket pomaže prodavcima da promovišu svoje proizvode ili usluge pružajući im više vidljivosti za oglase kako bi privukli više kupaca i brže prodali.',
  'ad' => 'Oglas',
  'availability' => 'Dostupnost',
  'days' => 'Dana',
  'promo duration' => 'Trajanje promocije',
  'ad limit' => 'Limit oglasa',
  'ad type' => 'Vrsta oglasa',
  'business package' => 'Poslovni paket',
  'coupons' => 'Kuponi',
  'coupon code' => 'Kod kupona',
  'offer' => 'Ponuda',
  'validity' => 'Važenje',
  'choose' => 'Izaberite svoje kategorije',
  'done' => 'Završeno',
  'sell' => 'Prodaja',  
);