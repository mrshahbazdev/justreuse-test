<?php
return array (
  'all categories' => 'Sve Kategorije',
'location' => 'Lokacija',
'sort_by_colon' => 'Sortiraj Po: ',
'recently_posted' => 'Nedavno Objavljeno',
'price_low_to_high' => 'Cena: Od Najniže Ka Najvišoj',
'price_high_to_low' => 'Cena: Od Najviše Ka Najnižoj',
'popular' => 'Popularno',
'Brands' => 'Brendovi',
'choose' => 'Izaberite svoje kategorije',
'done' => 'Završeno',
'sell' => 'Prodaja',
);