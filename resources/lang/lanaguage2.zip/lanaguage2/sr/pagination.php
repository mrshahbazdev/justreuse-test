<?php
return array (
  'previous' => '&laquo; Prethodno',
  'next' => 'Sledeće &raquo;',
  'choose' => 'Izaberite svoje kategorije',
  'done' => 'Završeno',
  'sell' => 'Prodaja',  
);