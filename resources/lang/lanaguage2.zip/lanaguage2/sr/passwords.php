<?php
return array (
  'reset' => 'Vaša lozinka je resetovana!',
  'sent' => 'Poslali smo vam link za resetovanje lozinke na vašu email adresu!',
  'throttled' => 'Molimo sačekajte pre ponovnog pokušaja.',
  'token' => 'Ovaj token za resetovanje lozinke nije validan.',
  'user' => 'Ne možemo pronaći korisnika sa tom email adresom.',
  'choose' => 'Izaberite svoje kategorije',
  'done' => 'Završeno',
  'sell' => 'Prodaja',  
);