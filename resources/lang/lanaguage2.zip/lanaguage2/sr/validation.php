<?php
return array (
  'accepted' => ':attribute mora biti prihvaćen.',
'active_url' => ':attribute nije validan URL.',
'after' => ':attribute mora biti datum posle :date.',
'after_or_equal' => ':attribute mora biti datum posle ili jednak :date.',
'alpha' => ':attribute može sadržati samo slova.',
'alpha_dash' => ':attribute može sadržati samo slova, brojeve, crtice i donje crte.',
'alpha_num' => ':attribute može sadržati samo slova i brojeve.',
'array' => ':attribute mora biti niz.',
'before' => ':attribute mora biti datum pre :date.',
'before_or_equal' => ':attribute mora biti datum pre ili jednak :date.',
'between' => 
  array (
    'numeric' => ':attribute mora biti između :min i :max.',
    'file' => ':attribute mora biti između :min i :max kilobajta.',
    'string' => ':attribute mora biti između :min i :max karaktera.',
    'array' => ':attribute mora imati između :min i :max stavki.',
  ),
'boolean' => 'Polje :attribute mora biti tačno ili netačno.',
'confirmed' => 'Potvrda :attribute se ne poklapa.',
'date' => ':attribute nije validan datum.',
'date_equals' => ':attribute mora biti datum jednak :date.',
'date_format' => ':attribute se ne poklapa sa formatom :format.',
'different' => ':attribute i :other moraju biti različiti.',
'digits' => ':attribute mora imati :digits cifara.',
'digits_between' => ':attribute mora biti između :min i :max cifara.',
'dimensions' => ':attribute ima nevažeće dimenzije slike.',
'distinct' => 'Polje :attribute ima dupliranu vrednost.',
'email' => ':attribute mora biti validna email adresa.',
'ends_with' => ':attribute mora završavati jednim od sledećih: :values.',
'exists' => 'Izabrano :attribute nije validno.',
'file' => ':attribute mora biti fajl.',
'filled' => 'Polje :attribute mora imati vrednost.',
'gt' => 
  array (
    'numeric' => ':attribute mora biti veći od :value.',
    'file' => ':attribute mora biti veći od :value kilobajta.',
    'string' => ':attribute mora biti duži od :value karaktera.',
    'array' => ':attribute mora imati više od :value stavki.',
  ),
'gte' => 
  array (
    'numeric' => ':attribute mora biti veći ili jednak :value.',
    'file' => ':attribute mora biti veći ili jednak :value kilobajta.',
    'string' => ':attribute mora biti duži ili jednak :value karaktera.',
    'array' => ':attribute mora imati :value ili više stavki.',
  ),
'image' => ':attribute mora biti slika.',
'in' => 'Izabrano :attribute nije validno.',
'in_array' => 'Polje :attribute ne postoji u :other.',
'integer' => ':attribute mora biti ceo broj.',
'ip' => ':attribute mora biti validna IP adresa.',
'ipv4' => ':attribute mora biti validna IPv4 adresa.',
'ipv6' => ':attribute mora biti validna IPv6 adresa.',
'json' => ':attribute mora biti validan JSON string.',
'lt' => 
  array (
    'numeric' => ':attribute mora biti manji od :value.',
    'file' => ':attribute mora biti manji od :value kilobajta.',
    'string' => ':attribute mora biti kraći od :value karaktera.',
    'array' => ':attribute mora imati manje od :value stavki.',
  ),
'lte' => 
  array (
    'numeric' => ':attribute mora biti manji ili jednak :value.',
    'file' => ':attribute mora biti manji ili jednak :value kilobajta.',
    'string' => ':attribute mora biti kraći ili jednak :value karaktera.',
    'array' => ':attribute ne sme imati više od :value stavki.',
  ),
'max' => 
  array (
    'numeric' => ':attribute ne sme biti veći od :max.',
    'file' => ':attribute ne sme biti veći od :max kilobajta.',
    'string' => ':attribute ne sme biti duži od :max karaktera.',
    'array' => ':attribute ne sme imati više od :max stavki.',
  ),
'mimes' => ':attribute mora biti fajl tipa: :values.',
'mimetypes' => ':attribute mora biti fajl tipa: :values.',
'min' => 
  array (
    'numeric' => ':attribute mora biti najmanje :min.',
    'file' => ':attribute mora biti najmanje :min kilobajta.',
    'string' => ':attribute mora imati najmanje :min karaktera.',
    'array' => ':attribute mora imati najmanje :min stavki.',
  ),
'multiple_of' => ':attribute mora biti višestruko od :value',
'not_in' => 'Izabrani :attribute nije validan.',
'not_regex' => 'Format :attribute nije validan.',
'numeric' => ':attribute mora biti broj.',
'password' => 'Lozinka nije ispravna.',
'present' => 'Polje :attribute mora biti prisutno.',
'regex' => 'Format :attribute nije validan.',
'required' => 'Polje :attribute je obavezno.',
'required_if' => 'Polje :attribute je obavezno kada :other ima vrednost :value.',
'required_unless' => 'Polje :attribute je obavezno osim ako :other nije u :values.',
'required_with' => 'Polje :attribute je obavezno kada je :values prisutno.',
'required_with_all' => 'Polje :attribute je obavezno kada su :values prisutna.',
'required_without' => 'Polje :attribute je obavezno kada :values nije prisutno.',
'required_without_all' => 'Polje :attribute je obavezno kada nijedno od :values nije prisutno.',
'same' => ':attribute i :other se moraju poklapati.',
'size' => 
  array (
    'numeric' => ':attribute mora biti :size.',
    'file' => ':attribute mora biti :size kilobajta.',
    'string' => ':attribute mora biti :size karaktera.',
    'array' => ':attribute mora sadržati :size stavki.',
  ),
'starts_with' => ':attribute mora početi sa jednim od sledećeg: :values.',
'string' => ':attribute mora biti string.',
'timezone' => ':attribute mora biti validna vremenska zona.',
'unique' => ':attribute već postoji.',
'uploaded' => ':attribute nije uspeo da se otpremi.',
'url' => 'Format :attribute nije validan.',
'uuid' => ':attribute mora biti validan UUID.',
'custom' => 
  array (
    'attribute-name' => 
    array (
      'rule-name' => 'custom-message',
    ),
  ),
'attributes' => 
  array (
  ),
'choose' => 'Izaberite svoje kategorije',
'done' => 'Završeno',
'sell' => 'Prodaja',
);