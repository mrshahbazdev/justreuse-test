<?php
return array (
  'failed' => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
  'password' => 'Sağlanan şifre yanlış.',
  'throttle' => 'Çok fazla giriş denemesi yapıldı. Lütfen :seconds saniye sonra tekrar deneyin.',
  'choose' => 'Kategorilerinizi Seçin',
  'done' => 'Tamam',
  'sell' => 'Satış',  
);