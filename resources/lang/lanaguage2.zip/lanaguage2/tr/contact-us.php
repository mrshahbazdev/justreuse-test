<?php
return array (
  'name' => 'İsim',
'email' => 'E-posta',
'ad link' => 'İlan Bağlantısı',
'phone' => 'Telefon',
'description' => 'Açıklama',
'attachment' => 'Ek Dosya',
'contact us' => 'Bize Ulaşın',
'submit' => 'Gönder',
'choose' => 'Kategorinizi Seçin',
'done' => 'Tamam',
'sell' => 'Satış',

);