<?php
return array (
  'sell and buy near you' => 'Yakınındaki satış ve alışveriş',
  'simple fast and efficient' => 'Basit, hızlı ve verimli',
  'top ads' => 'En İyi İlanlar',
  'view more' => 'DAHA FAZLA GÖRÜNTÜLE',
  'feature ads' => 'Öne Çıkan İlanlar',
  'latest ads' => 'Son İlanlar',
  'browsecategory' => 'Kategoriye Göz At',
  'categories' => 'Kategoriler',
  'choose' => 'Kategorinizi Seçin',
  'done' => 'Tamam',
  'sell' => 'Satış',  
);