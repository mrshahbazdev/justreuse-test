<?php
return array (
  'favourite ads' => 'Favori İlanlar',
  'select all' => 'Tümünü Seç',
  'delete' => 'Sil',
  'search here' => 'Burada Ara',
  'photo' => 'Fotoğraf',
  'ads details' => 'İlan Detayları',
  'price' => 'Fiyat',
  'action' => 'İşlem',
  'posted on' => 'Yayınlanma Tarihi',
  'no data found' => 'Veri bulunamadı!',
  'choose' => 'Kategorinizi Seçin',
  'done' => 'Tamam',
  'sell' => 'Satış',  
);