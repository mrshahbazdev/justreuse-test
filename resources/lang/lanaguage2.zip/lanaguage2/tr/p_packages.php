<?php
return array (
  'packages' => 'Paketler',
'package quotes' => 'Premium paket, satıcıların ürünlerini veya hizmetlerini daha fazla alıcı çekmek ve daha hızlı satmak için reklamlarına daha fazla görünürlük sağlar.',
'ad' => 'İlan',
'availability' => 'Kullanılabilirlik',
'days' => 'Günler',
'promo duration' => 'Promosyon Süresi',
'ad limit' => 'İlan limiti',
'ad type' => 'İlan Türü',
'business package' => 'İş Paketi',
'coupons' => 'Kuponlar',
'coupon code' => 'Kupon kodu',
'offer' => 'Teklif',
'validity' => 'Geçerlilik',
'choose' => 'Kategorinizi Seçin',
'done' => 'Tamam',
'sell' => 'Satış',
);