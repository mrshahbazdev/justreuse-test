<?php
return array (
  'all categories' => 'Tüm Kategoriler',
  'location' => 'Konum',
  'sort_by_colon' => 'Sırala: ',
  'recently_posted' => 'Son Eklenen',
  'price_low_to_high' => 'Fiyat: Düşükten Yükseğe',
  'price_high_to_low' => 'Fiyat: Yüksekten Düşüğe',
  'popular' => 'Popüler',
  'Brands' => 'Markalar',
  'choose' => 'Kategorinizi Seçin',
  'done' => 'Tamam',
  'sell' => 'Satış',  
);