<?php
return array (
  'previous' => '&laquo; Önceki',
'next' => 'Sonraki &raquo;',
'choose' => 'Kategorinizi Seçin',
'done' => 'Tamam',
'sell' => 'Satış',
);