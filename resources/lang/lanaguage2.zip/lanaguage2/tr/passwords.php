<?php
return array (
  'reset' => 'Şifreniz sıfırlandı!',
'sent' => 'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi!',
'throttled' => 'Tekrar denemeden önce lütfen bekleyin.',
'token' => 'Bu şifre sıfırlama belirteci geçersiz.',
'user' => 'Bu e-posta adresiyle ilişkili bir kullanıcı bulunamadı.',
'choose' => 'Kategorinizi Seçin',
'done' => 'Tamam',
'sell' => 'Satış',
);