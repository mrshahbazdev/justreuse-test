<?php
return array (
  'accepted' => ':Attribute kabul edilmelidir.',
  'active_url' => ':Attribute geçerli bir URL değil.',
  'after' => ':Attribute, :date tarihinden sonra bir tarih olmalıdır.',
  'after_or_equal' => ':Attribute, :date tarihinden sonra veya aynı tarih olmalıdır.',
  'alpha' => ':Attribute yalnızca harfleri içerebilir.',
  'alpha_dash' => ':Attribute yalnızca harfler, rakamlar, tireler ve alt çizgiler içerebilir.',
  'alpha_num' => ':Attribute yalnızca harf ve rakam içerebilir.',
  'array' => ':Attribute bir dizi olmalıdır.',
  'before' => ':Attribute, :date tarihinden önce bir tarih olmalıdır.',
  'before_or_equal' => ':Attribute, :date tarihinden önce veya aynı tarih olmalıdır.',
  'between' => 
  array (
    'numeric' => ':Attribute, :min ve :max arasında olmalıdır.',
    'file' => ':Attribute, :min ve :max kilobayt arasında olmalıdır.',
    'string' => ':Attribute, :min ve :max karakter arasında olmalıdır.',
    'array' => ':Attribute, :min ve :max öğe arasında olmalıdır.',
  ),
  'boolean' => ':Attribute alanı doğru veya yanlış olmalıdır.',
  'confirmed' => ':Attribute doğrulaması eşleşmiyor.',
  'date' => ':Attribute geçerli bir tarih değil.',
  'date_equals' => ':Attribute, :date ile aynı tarihte olmalıdır.',
  'date_format' => ':Attribute, :format biçimiyle eşleşmiyor.',
  'different' => ':Attribute ve :other farklı olmalıdır.',
  'digits' => ':Attribute, :digits basamaklı olmalıdır.',
  'digits_between' => ':Attribute, :min ile :max arasında basamaklı olmalıdır.',
  'dimensions' => ':Attribute geçersiz resim boyutlarına sahip.',
  'distinct' => ':Attribute alanı tekrarlanan bir değere sahiptir.',
  'email' => ':Attribute geçerli bir e-posta adresi olmalıdır.',
  'ends_with' => ':Attribute, aşağıdakilerden biriyle bitmelidir: :values.',
  'exists' => 'Seçili :attribute geçersiz.',
  'file' => ':Attribute bir dosya olmalıdır.',
  'filled' => ':Attribute alanı bir değer içermelidir.',
  'gt' => 
  array (
    'numeric' => ':Attribute, :value sayısından büyük olmalıdır.',
    'file' => ':Attribute, :value kilobayttan büyük olmalıdır.',
    'string' => ':Attribute, :value karakterden uzun olmalıdır.',
    'array' => ':Attribute, :value öğeden daha fazla olmalıdır.',
  ),
  'gte' => 
  array (
    'numeric' => ':Attribute, :value sayısından büyük veya eşit olmalıdır.',
    'file' => ':Attribute, :value kilobayttan büyük veya eşit olmalıdır.',
    'string' => ':Attribute, :value karakterden uzun veya eşit olmalıdır.',
    'array' => ':Attribute, :value veya daha fazla öğe içermelidir.',
  ),
  'image' => ':Attribute bir resim olmalıdır.',
  'in' => 'Seçili :attribute geçersiz.',
  'in_array' => ':Attribute alanı :other içinde mevcut değil.',
  'integer' => ':Attribute bir tam sayı olmalıdır.',
  'ip' => ':Attribute geçerli bir IP adresi olmalıdır.',
  'ipv4' => ':Attribute geçerli bir IPv4 adresi olmalıdır.',
  'ipv6' => ':Attribute geçerli bir IPv6 adresi olmalıdır.',
  'json' => ':Attribute geçerli bir JSON dizesi olmalıdır.',
  'lt' => 
  array (
    'numeric' => ':Attribute, :value sayısından küçük olmalıdır.',
    'file' => ':Attribute, :value kilobayttan küçük olmalıdır.',
    'string' => ':Attribute, :value karakterden kısa olmalıdır.',
    'array' => ':Attribute, :value öğeden az olmalıdır.',
  ),
  'lte' => 
  array (
    'numeric' => ':Attribute, :value sayısından küçük veya eşit olmalıdır.',
    'file' => ':Attribute, :value kilobayttan küçük veya eşit olmalıdır.',
    'string' => ':Attribute, :value karakterden kısa veya eşit olmalıdır.',
    'array' => ':Attribute, :value öğeden fazla olmamalıdır.',
  ),
  'max' => 
  array (
    'numeric' => ':Attribute, :max değerinden büyük olmamalıdır.',
    'file' => ':Attribute, :max kilobayttan büyük olmamalıdır.',
    'string' => ':Attribute, :max karakterden büyük olmamalıdır.',
    'array' => ':Attribute, :max öğeden fazla olmamalıdır.',
  ),
  'mimes' => ':Attribute, :values türünde bir dosya olmalıdır.',
  'mimetypes' => ':Attribute, :values türünde bir dosya olmalıdır.',
  'min' => 
  array (
    'numeric' => ':Attribute, en az :min olmalıdır.',
    'file' => ':Attribute, en az :min kilobayt olmalıdır.',
    'string' => ':Attribute, en az :min karakter olmalıdır.',
    'array' => ':Attribute, en az :min öğe içermelidir.',
  ),
  'multiple_of' => ':Attribute, :value sayısının katı olmalıdır',
  'not_in' => 'Seçili :attribute geçersiz.',
  'not_regex' => ':Attribute biçimi geçersiz.',
  'numeric' => ':Attribute bir sayı olmalıdır.',
  'password' => 'Parola geçersiz.',
  'present' => ':Attribute alanı mevcut olmalıdır.',
  'regex' => ':Attribute biçimi geçersiz.',
  'required' => ':Attribute alanı gereklidir.',
  'required_if' => ':Other değeri :value olduğunda, :attribute alanı gereklidir.',
  'required_unless' => ':Other :values içinde olmadığı sürece, :attribute alanı gereklidir.',
  'required_with' => ':Values mevcut olduğunda, :attribute alanı gereklidir.',
  'required_with_all' => ':Values mevcut olduğunda, :attribute alanı gereklidir.',
  'required_without' => ':Values olmadığında, :attribute alanı gereklidir.',
  'required_without_all' => ':Values hiçbiri mevcut değilse, :attribute alanı gereklidir.',
  'same' => ':Attribute ve :other eşleşmelidir.',
  'size' => 
  array (
    'numeric' => ':Attribute, :size olmalıdır.',
    'file' => ':Attribute, :size kilobayt olmalıdır.',
    'string' => ':Attribute, :size karakter olmalıdır.',
    'array' => ':Attribute, :size öğe içermelidir.',
  ),
  'starts_with' => ':Attribute, aşağıdakilerden biriyle başlamalıdır: :values.',
  'string' => ':Attribute bir dize olmalıdır.',
  'timezone' => ':Attribute geçerli bir bölge olmalıdır.',
  'unique' => ':Attribute zaten alınmış.',
  'uploaded' => ':Attribute yüklenemedi.',
  'url' => ':Attribute biçimi geçersiz.',
  'uuid' => ':Attribute geçerli bir UUID olmalıdır.',
  'custom' => 
  array (
    'attribute-name' => 
    array (
      'rule-name' => 'özel-ileti',
    ),
  ),
  'attributes' => 
  array (
  ),
  'choose' => 'Kategorinizi Seçin',
  'done' => 'Tamam',
  'sell' => 'Satış',  
  );