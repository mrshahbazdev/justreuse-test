<div class="root-element-div">

    <?php
    $get_meta = App\Models\TblOtherpage::get_meta('post-edit');
    $meta_title = (!empty($get_meta->meta_title) ? $get_meta->meta_title : "");
    $meta_keywords = (!empty($get_meta->meta_key) ? $get_meta->meta_key : "");
    $meta_description = (!empty($get_meta->meta_description) ? $get_meta->meta_description : "");


    $dir_rtl =  App\Models\Setting::is_dir_rtl();
    $class_dir = ($dir_rtl == "true") ? 'dir=rtl' : "";

    $class_dir_sm_mar_rl = ($dir_rtl == "true") ? 'sm:ml-10' : 'sm:mr-10';
    $class_dir_pad_rl = ($dir_rtl == "true") ? 'pl-3' : 'pr-3';
    $class_dir_float_lr = ($dir_rtl == "true") ? 'float-right' : 'float-left';
    $class_dir_float_rl = ($dir_rtl == "true") ? 'float-left' : 'float-right';
    $class_dir_sm_space_r = ($dir_rtl == "true") ? 'sm:space-x-reverse' : '';
    $class_dir_lg_space_r = ($dir_rtl == "true") ? 'lg:space-x-reverse' : '';

    ?>

    @if(!empty($meta_title) && !empty($meta_keywords) && !empty($meta_description))
    @section('meta_title', $meta_title)
    @section('meta_keywords', $meta_keywords)
    @section('meta_description', $meta_description)
    @endif

    <!-- Post Ad Details Content -->

    <div class="w-full float-left my-6" {{$class_dir}}>
        <div class="container mx-auto px-4">
            <div class="w-full float-left border rounded-xl border-gray-300 px-4 py-4 xl:px-10 xl:py-7">
                <form class="w-full float-left" action="{{ URL::to('update_post_info') }}" method="POST" name="post-add" onsubmit="return validateForm()" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="post-id" value="{{ $info_post[0]->id }}" />
                    <div class="mb-4 sm:mb-8 md:mb-10 lg:mb-12 xl:mb-14">
                        <h2 class="text-black text-xl md:text-2xl lg:text-3xl xl:text-4xl font-bold">{{__('p_myads.post free ads')}}</h2>
                    </div>


                    <div class="w-full block mb-4 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                        <div class="inline-block block text-gray-400 text-xs font-bold">
                            @if($ancestors!="")
                            <?php
                            echo '<ul class="flex text-black text-sm lg:text-base">';
                            echo "<li class='font-semibold'>Category <i class='fa fa-angle-double-right'></i></li>";
                            $i = 1;
                            foreach ($ancestors as $r) {
                                $totcount = $ancestors->count();
                                $catname = "&nbsp;" . $r->title;
                                if ($i != $totcount) {
                                    echo '<li class="font-semibold">' . $catname . ' <i class="fa fa-angle-double-right"></i></li>';
                                } else {
                                    echo '<li class="text-green-500 font-semibold">' . $catname . '</li>';
                                }
                                $i++;
                            }
                            echo "</ul>";
                            ?>
                            @endif
                        </div>
                    </div>

                    <div class="w-full float-left xl:px-16">
                        <div class="flex flex-wrap">


                            <div class="w-full float-left order-1 sm:order-2">


                                <div class="sm:flex sm:space-x-2 {{$class_dir_sm_space_r}} lg:space-x-6 {{$class_dir_lg_space_r}} sm:mb-6 md:mb-8 lg:mb-10 w-full">
                                    <div class="w-full sm:w-1/2 mb-4 sm:mb-0">
                                        <label class="block text-base text-black font-semibold mb-2 sm:mb-4 poppins-500"> {{__('p_myads.ad title')}} <span class="text-red-800">*</span></label>
                                        <input type="text" class="check_blacklist_title w-full h-14  px-6 py-4 text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none  placeholder-black" value="{{ $info_post[0]->title }}" name="text-title-sst" id="text-title-sst" required="required">
                                    </div>

                                    <div class="w-full sm:w-1/2 mb-4 sm:mb-0">
                                        <label class="block text-base text-black font-semibold mb-2 sm:mb-4" htmlfor="grid-password">{{__('p_myads.price')}} <span class="text-red-800">*</span></label>
                                        <div class="flex flex-row">
                                            <span class="sub-field text-center bg-grey-lighter rounded rounded-r-none {{$class_dir_pad_rl}} text-xs font-bold w-4/6 xl:w-4/12">
                                                <select id="currency_id" class="w-full h-14  px-2 py-2 md:px-4 md:py-4 text-sm sm:text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none  placeholder-black text-center " name="currency_id">
                                                    <?php
                                                    $currency = App\Models\TblCurrency::where('active', '0')->orderBy('id', 'desc')->get();
                                                    foreach ($currency as $currency) {
                                                    ?>
                                                        <option value="<?php echo $currency->id ?>" <?php echo ($currency->id == $info_post[0]->currency_id) ? "selected" : ""; ?>><?php echo $currency->short_code . " (" . $currency->currency_hex . ")" ?></option>
                                                    <?php } ?>
                                                </select>
                                            </span>
                                            <input type="number" class="w-full h-14 rounded-lg px-6 py-4 text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none  placeholder-black" value="{{ $info_post[0]->price }}" name="number-price-sst" id="number-price-sst" min="0" required="required">
                                        </div>
                                    </div>
                                </div>




                                <div class="w-full block mb-4 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                                    <label class="block text-base text-black font-semibold mb-2 sm:mb-4">{{__('p_myads.description')}} <span class="text-red-800">*</span></label>
                                    <textarea class="check_blacklist_detail w-full h-36  px-6 py-4 text-base text-black border-l-4 border-green-800 bg-gray-100 focus:outline-none  placeholder-black" name="textarea-desc-sst" id="textarea-desc-sst" required="required">{{ $info_post[0]->description }}</textarea>
                                </div>


                                <div class="w-full float-left">
                                    <div class="w-full block mb-4 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                                        <div class="relative w-full float-left mt-2 mb-4 sm:m-0">
                                            <div class="w-full float-left">
                                                <div class="w-full rounded-lg bg-gray-100 float-left">
                                                    <div class="w-full p-4 float-left">
                                                        <div class="w-full float-left py-6 post_add_img_upload" wire:ignore="">

                                                            <div class="input-images border-4 border-solid rounded-3xl hover:bg-gray-100 hover:border-gray-300 cursor-pointer relative h-52 sm:h-64 md:h-72 lg:h-80 pt-10 pb-6 w-full sm:w-1/2 {{$class_dir_float_lr}}">
                                                                <div class="absolute flex flex-col items-center top-0 bottom-0 left-0 right-0 justify-center text-center">
                                                                    <div class="text-4xl font-normal text-gray-200 group-hover:text-gray-600">
                                                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                                                    </div>
                                                                    <p class="text-xl text-gray-500 font-semibold group-hover:text-gray-600">Upload Photos</p>
                                                                </div>
                                                            </div>
                                                            <div class="w-full sm:w-1/2 {{$class_dir_float_lr}}">
                                                                @include('livewire.common.multiple_image')

                                                                <?php
                                                                $imgs = !empty($info_post[0]->images) ? explode(',', $info_post[0]->images) : array();
                                                                if (count($imgs) > 0 && $info_post[0]->images != "") {
                                                                    foreach ($imgs as $img) {
                                                                        $imageUrl = URL::to('storage/' . $img);
                                                                ?>
                                                                        <div class="w-1/2 md:w-1/3 lg:w-1/4 {{$class_dir_float_lr}}">
                                                                            <div class="remove-img-div m-4 text-center">
                                                                                <img class="w-full object-cover object-center h-24 w-24 mx-auto sm:w-auto sm:h-20 lg:h-24" src="{{$imageUrl}}" alt="img-pre" />
                                                                                <input type="hidden" name="old_images[]" value="{{$img}}">
                                                                                <button class="text-red-700 remove-img">
                                                                                    <i class="fa fa-times-circle" aria-hidden="true"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                <?php
                                                                    }
                                                                }
                                                                ?>

                                                                <?php
                                                                $img_limit = App\Models\Setting::get_image_size_settings();
                                                                ?>
                                                                <input type="hidden" class="upload_img_count" value="<?php echo count($imgs); ?>" />
                                                                <input type="hidden" class="max_img_upload_count" value="<?php echo !empty($img_limit['max_image_limit']) ? $img_limit['max_image_limit'] : 5; ?>" />
                                                                <input type="hidden" class="upload_page" value="Edit" />
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="sm:flex sm:space-x-2 lg:space-x-6 sm:float-none float-left w-full">
                                    <div class="w-full block mb-4 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                                        <label class="block text-base text-black font-semibold mb-2 sm:mb-4">{{__('p_myads.city')}} <span class="text-red-800">*</span></label>
                                        <input type="text" class="w-full h-14  px-6 py-4 text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none  placeholder-black" value="{{ !empty($info_post[0]->locality) ? $info_post[0]->locality : $info_location[0]->name }}" name="text-city-sst" id="searchTextField" required="required">

                                        <input type="hidden" id="cName" name="city_name" size="50" value="{{ $info_location[0]->locality }}" />
                                        <input type="hidden" id="cityMain" name="main_city_name" size="50" value="{{ $info_location[0]->name }}" />
                                        <input type="hidden" id="cityLat" name="city_lat" size="50" value="{{ $info_location[0]->latitude }}" />
                                        <input type="hidden" id="cityLag" name="city_lag" size="50" value="{{ $info_location[0]->logitude }}" />
                                        <input type="hidden" id="country_long" name="country_long" size="50" value="{{ $info_location[0]->country_long }}" />
                                        <input type="hidden" id="country_short" name="country_short" size="50" value="{{ $info_location[0]->country_short }}" />
                                        <input type="hidden" id="state_long" name="state_long" size="50" value="{{ $info_location[0]->state_long }}" />
                                        <input type="hidden" id="state_short" name="state_short" size="50" value="{{ $info_location[0]->state_short }}" />
                                        <input type="hidden" name="post-catid-sst" id="id_post_catid" value="{{ $info_post[0]->category_id }}" />



                                    </div>

                                </div>


                                <div class="w-full block mb-2 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                                    <h2 class="text-black text-lg md:text-xl lg:text-2xl xl:text-3xl font-bold sm:mt-0 mt-2 text-green-500">{{__('p_myads.what is your expectation and details')}}?</h2>
                                    <div id="pc_html"></div>
                                </div>

                                <?php $post_methods = App\Models\TblPostMethod::get_active_post_methods(); ?>

                                <!--row 6-->
                                <div class="w-full float-left mb-4 sm:mb-8 md:mb-10 lg:b-12">
                                    <ul class="sm:inline-flex w-full">
                                        @foreach($post_methods as $post_method)
                                        @if($post_method->name == "exchange")
                                        <li class="float-left w-full sm:w-auto mb-4 sm:mb-0">
                                            <!-- Toggle Exchange to Buy -->
                                            <label for="Products_exchangeToBuy" class="w-full sm:w-auto float-left cursor-pointer block text-base text-black font-semibold {{$class_dir_sm_mar_rl}} text-green-500">{{__('post_detail.exchange to buy')}}
                                                <!-- toggle -->
                                                <div class="relative mt-0 sm:mt-3 {{$class_dir_float_rl}} sm:float-none">
                                                    <!-- input -->
                                                    <input type="checkbox" id="Products_exchangeToBuy" class="sr-only" name="exchangeToBuy" value="1" <?php echo ($info_post[0]->exchange_to_buy == 1) ? "checked" : ""; ?>>
                                                    <!-- line -->
                                                    <div class="block bg-gray-200 w-16 lg:w-20 h-9 lg:h-11 rounded-full"></div>
                                                    <!-- dot -->
                                                    <div class="dot absolute left-1 top-1 bg-gray-400 w-7 lg:w-9 h-7 lg:h-9 rounded-full transition"></div>
                                                </div>
                                                <!-- label -->
                                            </label>
                                        </li>
                                        @endif
                                        @if($post_method->name == "buynow")
                                        <li class="float-left w-full sm:w-auto mb-4 sm:mb-0">
                                            <label for="Products_InstantBuy" class="w-full sm:w-auto float-left cursor-pointer block text-base text-black font-semibold {{$class_dir_sm_mar_rl}}">{{__('p_myads.instant buy')}}
                                                <!-- toggle -->
                                                <div class="relative mt-0 sm:mt-3 {{$class_dir_float_rl}} sm:float-none">
                                                    <!-- input -->
                                                    <input id="Products_InstantBuy" class="sr-only" type="checkbox" name="InstantBuy" value="1" <?php echo ($info_post[0]->instant_buy == 1) ? "checked" : ""; ?>>

                                                    <!-- line -->
                                                    <div class="block bg-gray-200 w-16 lg:w-20 h-9 lg:h-11 rounded-full"></div>
                                                    <!-- dot -->
                                                    <div class="dot absolute left-1 top-1 bg-gray-400 w-7 lg:w-9 h-7 lg:h-9 rounded-full transition"></div>
                                                </div>
                                                <!-- label -->
                                            </label>
                                        </li>

                                        @endif
                                        @endforeach
                                        <li class="float-left w-full sm:w-auto">
                                            <label for="Products_FixedPrice" class="w-full sm:w-auto float-left cursor-pointer block text-base text-black font-semibold {{$class_dir_sm_mar_rl}}">{{__('p_myads.fixed price')}}
                                                <!-- toggle -->
                                                <div class="relative mt-0 sm:mt-3 {{$class_dir_float_rl}} sm:float-none">
                                                    <!-- input -->
                                                    <input id="Products_FixedPrice" class="sr-only" type="checkbox" name="FixedPrice" value="1" <?php echo ($info_post[0]->fixed_price == 1) ? "checked" : ""; ?>>
                                                    <!-- line -->
                                                    <div class="block bg-gray-200 w-16 lg:w-20 h-9 lg:h-11 rounded-full"></div>
                                                    <!-- dot -->
                                                    <div class="dot absolute left-1 top-1 bg-gray-400 w-7 lg:w-9 h-7 lg:h-9 rounded-full transition"></div>
                                                </div>
                                                <!-- label -->
                                            </label>
                                        </li>
                                    </ul>
                                </div>

                                <!--row 7 -- hidden -->
                                <div class="w-full block mb-2 sm:mb-6 md:mb-8 lg:mb-10 float-left shipping_fee">
                                    <label class="text-black text-lg md:text-xl lg:text-2xl xl:text-3xl font-bold sm:mt-0 mt-2">{{__('p_myads.quick buying information')}}</label>
                                    <label class="block text-base text-black font-semibold mb-2 sm:mb-4 mt-4">{{__('p_myads.shipping cost')}}</label>
                                    <input type="text" placeholder="Shipping Cost" class="w-full h-14 rounded-lg px-6 py-4 text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none placeholder-black pac-target-input" value="{{ $info_post[0]->shipping_rate }}" name="text-shipping-fee" id="text-shipping-fee">
                                </div>


                                <div class="flex flex-wrap mt-3 w-full float-left" id="fb-render">{!! $custJson !!}</div>

                                <div class="w-full block mb-2 sm:mb-6 md:mb-8 lg:mb-10 float-left">
                                    <h2 class="text-black text-lg md:text-xl lg:text-2xl xl:text-3xl font-bold sm:mt-0 mt-2 text-green-500">{{__('p_myads.youtube video embed url')}}</h2>
                                </div>

                                <!--row 9-->
                                <div class="w-full float-left mb-4 sm:mb-8 md:mb-10 lg:mb-12">
                                    <label class="block text-base text-black font-semibold mb-2 sm:mb-4">{{__('p_myads.product video')}} <span class="text-red-800">*</span></label>
                                    <input type="text" placeholder="Example: https://www.youtube.com/embed/9xwazD5SyVg" class="w-full h-14  px-6 py-4 text-base text-black border-l-2 border-green-800 bg-gray-100 focus:outline-none  placeholder-gray-400" value="{{ $info_post[0]->video_url }}" name="text-video-sst" id="text-video-sst">
                                </div>

                            </div>
                        </div>


                        <div class="w-full block float-left text-center my-2">
                            <button class="bg-green-500 py-3 poppins-500 px-14 pb-3 inline-block rounded-md text-white text-base  outline-none focus:outline-none hover:text-green-500 border-2  hover:bg-white transition ease-in-out duration-500 w-full sm:w-auto mb-4 sm:mb-0">{{__('p_profile.update')}}</button>
                            <button class="bg-orange py-3 poppins-500 px-14 pb-3 inline-block rounded-md text-white text-base  outline-none focus:outline-none hover:text-green-500  hover:bg-white transition ease-in-out duration-500 w-full sm:w-auto"><a href="{{URL::to('/post')}}">{{__('p_myads.cancel')}}</a></button>
                        </div>




                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Post Ad Details Content -->

    <?php $blacklist_words = App\Models\TblPost::get_blacklist(); ?>
    {!! config('app.google_map_script') !!}
    <script>
        <?php if ($info_post[0]->instant_buy == 0) { ?>
            $(".shipping_fee").hide();
        <?php } ?>

        function validateForm() {
            var city_name = document.forms["post-add"]["city_name"].value;
            var country_name = document.forms["post-add"]["country_long"].value;
            var state_name = document.forms["post-add"]["state_long"].value;
            var video = document.forms["post-add"]["text-video-sst"].value;
            var buynow = document.forms["post-add"]["InstantBuy"].value;
            if (city_name == null || city_name == "") {
                $("#searchTextField").focus();
                $("#searchTextField").val("");
                $("#searchTextField").attr("required", true);
                return false;
            } else if (city_name == country_name) {
                $("#searchTextField").focus();
                $("#searchTextField").val("");
                toastr.warning("Please choose the locality address only!");
                $("#searchTextField").attr("required", true);
                return false;
            } else if (city_name == state_name) {
                $("#searchTextField").focus();
                $("#searchTextField").val("");
                toastr.warning("Please choose the locality address only!");
                $("#searchTextField").attr("required", true);
                return false;
            } else if (country_name == "" || country_name == null) {
                $("#searchTextField").focus();
                $("#searchTextField").val("");
                toastr.warning("Invalid address, please choose valid address!");
                $("#searchTextField").attr("required", true);
                return false;
            } else if (state_name == "" || state_name == null) {
                $("#searchTextField").focus();
                $("#searchTextField").val("");
                toastr.warning("Invalid address, please choose valid address!");
                $("#searchTextField").attr("required", true);
                return false;
            } else if (video != "") {
                if (video != undefined || video != '') {
                    var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
                    var match = video.match(regExp);
                    if (match && match[2].length == 11) {} else {
                        toastr.warning("Invalid youtube url!");
                        return false;
                    }
                }
            } else if (buynow == 1) {
                var shipping_rate = document.forms["post-add"]["text-shipping-fee"].value;
                if (shipping_rate == "" || shipping_rate == null) {
                    toastr.warning("Please include shipping rate!");
                    $("#text-shipping-fee").attr("required", true);
                    return false;
                }
            }
        }
        //Remove the old image 
        $('.remove-img').on('click', function(event) {
            if (confirm('Are you sure to delete the image?')) {
                if ($(".upload_img_count").val() > 0) {
                    var imgcount = $(".upload_img_count").val();
                    var sub = imgcount - 1;
                    $(".upload_img_count").val(parseInt(sub));
                }
                $(this).closest(".remove-img-div").remove();
            } else {
                event.preventDefault();
            }
        });
        $(document).ready(function() {
            $("#Products_InstantBuy").on('change', function(e) {
                if (this.checked) {
                    $(".shipping_fee").show();
                    $("#text-shipping-fee").attr("required", true);
                } else {
                    $(".shipping_fee").hide();
                    $("#text-shipping-fee").attr("required", false);
                }
            });
        });
        //*Allow decimals only
        $("#text-shipping-fee").on("input", function(evt) {
            var self = $(this);
            self.val(self.val().replace(/[^0-9\.]/g, ''));
            if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) {
                evt.preventDefault();
            }
        });
        //*
        //prevent enter submit
        window.addEventListener('load', event => {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
        //Select - On change filling process - begin
        window.addEventListener('contentChanged', event => {
            $("#fb-render").html('');
            $("#pc_html").html('');
            $("#fb-render .models-select").html('');
            $("#fb-render").html(event.detail.custJson1);
            $("#fb-render .models-select").html(event.detail.modelHtml1);
            $("#pc_html").html(event.detail.pc_html1);
            document.getElementById('id_post_catid').value = event.detail.catId;
        });
        //Select - On change filling process - end
        //Save process start  
        jQuery(function($) {
            var options = {
                types: ['(regions)']
            };
            //  componentRestrictions: {country: "us"} //restric country if need
            //for location search map
            var input = document.getElementById('searchTextField');
            var autocomplete = new google.maps.places.Autocomplete(input);
            google.maps.event.addDomListener(input, 'keydown', function(event) {
                if (event.keyCode === 13) {
                    event.preventDefault();
                }
            });
            google.maps.event.addListener(autocomplete, 'place_changed', function() {
                $('#cName').val('');
                $('#cityMain').val('');
                $('#cityLat').val('');
                $('#cityLag').val('');
                $('#country_long').val('');
                $('#country_short').val('');
                $('#state_long').val('');
                $('#state_short').val('');
                var place = autocomplete.getPlace();
                const country = place.address_components.find(item => item.types.includes('country'));
                 // Find city based on administrative_area_level_1
                const cityComponent = place.address_components.find(item => item.types.includes('locality') || item.types.includes('administrative_area_level_2') || item.types.includes('administrative_area_level_1'));
                
                const city = cityComponent ? cityComponent : '';
                const state = place.address_components.find(item => item.types.includes('administrative_area_level_1'));
               
                $('#cName').val(place.name);
                $('#cityMain').val(city.long_name);
                $('#cityLat').val(place.geometry.location.lat());
                $('#cityLag').val(place.geometry.location.lng());
                $('#country_long').val(country.long_name);
                $('#country_short').val(country.short_name);
                $('#state_long').val(state.long_name);
                $('#state_short').val(state.short_name);
            });
            //for location search map
            var getUserDataBtn = document.getElementById("post_json_insert");
            getUserDataBtn.addEventListener("click", () => {
                var $fileUpload = $("#predefined_images");
                if (parseInt($fileUpload.get(0).files.length) > 5) {
                    alert("You are only allowed to upload a maximum of 5 files");
                    return false;
                }
                if ($("#selected_category").val() == 0) {
                    $("#selected_category").focus();
                    return false;
                }
                if ($("#text-title-sst").val() == "") {
                    $("#text-title-sst").focus();
                    return false;
                }
                if ($("#number-price-sst").val() == "") {
                    $("#number-price-sst").focus();
                    return false;
                }
                if ($("#textarea-desc-sst").val() == "") {
                    $("#textarea-desc-sst").focus();
                    return false;
                }
                if ($("#product-condition-sst").val() == "") {
                    $("#product-condition-sst").focus();
                    return false;
                }
                if ($("#cName").val() == "") {
                    $("#searchTextField").focus();
                    return false;
                }
            }, false);
        });
        // remove blacklist words
        $(document).ready(function() {
            $(".check_blacklist_title").on('keyup', function(e) {
                var blacklist = <?php echo $blacklist_words; ?>;
                var words = $(".check_blacklist_title").val();
                var str = words.trim().split(" ");
                var lastWord = str[str.length - 1];
                var lowerword = lastWord.toLowerCase();
                var array_index = jQuery.inArray(lowerword, blacklist);
                if (array_index >= 0) {
                    $(".check_blacklist_title").val($(".check_blacklist_title").val().replace(lastWord, ''));
                }
            });
        });
        // remove blacklist words
        $(document).ready(function() {
            $(".check_blacklist_detail").on('keyup', function(e) {
                var blacklist = <?php echo $blacklist_words; ?>;
                var words = $(".check_blacklist_detail").val();
                var str = words.trim().split(" ");
                var lastWord = str[str.length - 1];
                var lowerword = lastWord.toLowerCase();
                var array_index = jQuery.inArray(lowerword, blacklist);
                if (array_index >= 0) {
                    $(".check_blacklist_detail").val($(".check_blacklist_detail").val().replace(lastWord, ''));
                }
            });
        });

        /* Republish post */
        $(document).ready(function() {
            $(".brands-select").change(function(e) {
                var brands = $(this).val();
                if ((brands != "") && (brands != "undefined") && (brands != null)) {
                    get_custom_models(brands);
                }
            });

            function get_custom_models(brands) {
                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: "{{ route('get_custom_models') }}",
                    data: {
                        id: brands,
                    },
                    success: function(data) {
                        $(".models-select").html(data.data);
                    }
                });
            }
        });
    </script>

</div>